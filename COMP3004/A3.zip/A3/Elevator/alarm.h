#ifndef ALARM_H
#define ALARM_H

#include <QDialog>

class alarm
{
public:
    alarm();
    void ring();
    void callSafety();

};

#endif // ALARM_H
